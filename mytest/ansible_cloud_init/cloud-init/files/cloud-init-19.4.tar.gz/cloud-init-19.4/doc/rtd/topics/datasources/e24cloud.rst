.. _datasource_e24cloud:

E24Cloud
========
`E24Cloud <https://www.e24cloud.com/en/>` platform provides an AWS Ec2 metadata
service clone.  It identifies itself to guests using the dmi
system-manufacturer (/sys/class/dmi/id/sys_vendor).

.. vi: textwidth=78
