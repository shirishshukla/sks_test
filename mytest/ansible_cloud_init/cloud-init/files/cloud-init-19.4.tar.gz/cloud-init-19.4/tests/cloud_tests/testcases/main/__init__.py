# This file is part of cloud-init. See LICENSE file for license information.

"""Test verifiers for cloud-init main features.

See configs/main/README.md for more information
"""

# vi: ts=4 expandtab
