#!/bin/sh

#sleep_time='$1';
file_name="$1"

echo "hello, ansible" >> "$file_name"